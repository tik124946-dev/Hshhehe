package com.clumsynx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Плавающая кнопка поверх всех приложений: пауза/продолжить + стоп. Красная — интернет не идёт, зелёная — работает. */
class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var pauseBtn: TextView? = null
    private var stopBtn: TextView? = null
    private var lastX = 40
    private var lastY = 300
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refreshColors(); h.postDelayed(this, 300) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        build()
        return START_STICKY
    }

    private fun goForeground() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fab", "ClumsyNX", NotificationManager.IMPORTANCE_MIN))
            val n = Notification.Builder(this, "fab")
                .setSmallIcon(android.R.drawable.ic_media_pause)
                .setContentTitle("ClumsyNX")
                .setContentText("Плавающая кнопка активна")
                .build()
            startForeground(7, n)
        } catch (e: Exception) { }
    }

    private fun circle(text: String, px: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px * 0.38f)
        t.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.RED) }
        val p = LinearLayout.LayoutParams(px, px)
        p.setMargins(6, 6, 6, 6)
        t.layoutParams = p
        return t
    }

    private fun build() {
        removeView()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (Store(this).fabSize * resources.displayMetrics.density).toInt()
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.HORIZONTAL
        val pb = circle("▶", size)
        val sb = circle("■", (size * 0.75f).toInt())
        ll.addView(pb)
        ll.addView(sb)
        pauseBtn = pb
        stopBtn = sb
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.x = lastX
        l.y = lastY
        lp = l
        root = ll
        drag(pb) { onPause() }
        drag(sb) { vpnCmd(this, "STOP") }
        try {
            wm.addView(ll, l)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        refreshColors()
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun onPause() {
        if (!VpnState.running.value) {
            try {
                if (VpnService.prepare(this) == null) vpnCmd(this, null) else openApp()
            } catch (e: Exception) { openApp() }
        } else {
            vpnCmd(this, if (VpnState.paused.value) "RESUME" else "PAUSE")
        }
    }

    private fun openApp() {
        try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    private fun drag(v: View, click: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            val l = lp
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = l?.x ?: 0; oy = l?.y ?: 0; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved && l != null) {
                        l.x = ox + dx.toInt(); l.y = oy + dy.toInt()
                        lastX = l.x; lastY = l.y
                        try { wm.updateViewLayout(root, l) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) click()
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshColors() {
        val running = VpnState.running.value
        val paused = VpnState.paused.value
        val green = running && !paused
        pauseBtn?.text = if (green) "❚❚" else "▶"
        (pauseBtn?.background as? GradientDrawable)?.setColor(if (green) Color.parseColor("#1FBF4B") else Color.parseColor("#E5171F"))
        (stopBtn?.background as? GradientDrawable)?.setColor(Color.parseColor("#33333A"))
    }

    private fun removeView() {
        try { root?.let { wm.removeView(it) } } catch (e: Exception) { }
        root = null
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        removeView()
        super.onDestroy()
    }
}
