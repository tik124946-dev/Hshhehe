package com.clumsynx.app

import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Чтобы коды и пользователи были общими для всех устройств, создай проект Firebase
 * (Firestore) и впиши сюда PROJECT и API_KEY. Пока пусто — всё хранится только на этом телефоне.
 */
object Config {
    const val PROJECT = ""
    const val API_KEY = ""
}

data class CodeRec(
    val code: String,
    val label: String,
    val active: Boolean,
    val expires: Long, // 0 = бессрочно
    val maxDev: Int,
    val devices: List<String>
) {
    fun toJson(): JSONObject = JSONObject().put("c", code).put("l", label).put("a", active)
        .put("e", expires).put("m", maxDev).put("d", devices.joinToString(","))

    companion object {
        fun fromJson(o: JSONObject) = CodeRec(
            o.getString("c"), o.optString("l"), o.optBoolean("a", true), o.optLong("e", 0),
            o.optInt("m", 1), o.optString("d").split(",").filter { it.isNotBlank() }
        )
    }
}

data class UserRec(val id: String, val model: String, val lastSeen: Long, val code: String, val banned: Boolean) {
    fun toJson(): JSONObject = JSONObject().put("i", id).put("m", model).put("t", lastSeen)
        .put("c", code).put("b", banned)

    companion object {
        fun fromJson(o: JSONObject) = UserRec(
            o.getString("i"), o.optString("m"), o.optLong("t", 0), o.optString("c"), o.optBoolean("b", false)
        )
    }
}

object Backend {
    val enabled: Boolean get() = Config.PROJECT.isNotBlank()

    private fun fv(v: Any): JSONObject = when (v) {
        is Boolean -> JSONObject().put("booleanValue", v)
        is Long -> JSONObject().put("integerValue", v.toString())
        is Int -> JSONObject().put("integerValue", v.toString())
        else -> JSONObject().put("stringValue", v.toString())
    }

    private fun gs(f: JSONObject, k: String): String = f.optJSONObject(k)?.optString("stringValue", "") ?: ""
    private fun gl(f: JSONObject, k: String): Long = f.optJSONObject(k)?.optString("integerValue", "0")?.toLongOrNull() ?: 0L
    private fun gb(f: JSONObject, k: String): Boolean = f.optJSONObject(k)?.optBoolean("booleanValue", false) ?: false

    private fun req(method: String, path: String, body: JSONObject?): JSONObject? {
        return try {
            val sep = if (path.contains("?")) "&" else "?"
            val u = URL("https://firestore.googleapis.com/v1/projects/${Config.PROJECT}/databases/(default)/documents/$path${sep}key=${Config.API_KEY}")
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            if (method == "PATCH") {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            } else {
                c.requestMethod = method
            }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: "{}"
            if (code in 200..299) JSONObject(if (txt.isBlank()) "{}" else txt) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun docs(path: String): List<JSONObject> {
        val r = req("GET", "$path?pageSize=300", null) ?: return emptyList()
        val a = r.optJSONArray("documents") ?: JSONArray()
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    private fun idOf(d: JSONObject) = d.optString("name").substringAfterLast("/")

    fun getCode(code: String): CodeRec? {
        val d = req("GET", "codes/$code", null) ?: return null
        val f = d.optJSONObject("fields") ?: return null
        return CodeRec(code, gs(f, "label"), gb(f, "active"), gl(f, "expires"), gl(f, "maxDev").toInt(),
            gs(f, "devices").split(",").filter { it.isNotBlank() })
    }

    fun putCode(c: CodeRec) {
        val f = JSONObject().put("label", fv(c.label)).put("active", fv(c.active)).put("expires", fv(c.expires))
            .put("maxDev", fv(c.maxDev)).put("devices", fv(c.devices.joinToString(",")))
        req("PATCH", "codes/${c.code}", JSONObject().put("fields", f))
    }

    fun delCode(code: String) { req("DELETE", "codes/$code", null) }

    fun listCodes(): List<CodeRec> = docs("codes").mapNotNull { d ->
        val f = d.optJSONObject("fields") ?: return@mapNotNull null
        CodeRec(idOf(d), gs(f, "label"), gb(f, "active"), gl(f, "expires"), gl(f, "maxDev").toInt(),
            gs(f, "devices").split(",").filter { it.isNotBlank() })
    }

    fun getUser(id: String): UserRec? {
        val d = req("GET", "users/$id", null) ?: return null
        val f = d.optJSONObject("fields") ?: return null
        return UserRec(id, gs(f, "model"), gl(f, "lastSeen"), gs(f, "code"), gb(f, "banned"))
    }

    fun putUser(u: UserRec) {
        val f = JSONObject().put("model", fv(u.model)).put("lastSeen", fv(u.lastSeen))
            .put("code", fv(u.code)).put("banned", fv(u.banned))
        req("PATCH", "users/${u.id}", JSONObject().put("fields", f))
    }

    fun listUsers(): List<UserRec> = docs("users").mapNotNull { d ->
        val f = d.optJSONObject("fields") ?: return@mapNotNull null
        UserRec(idOf(d), gs(f, "model"), gl(f, "lastSeen"), gs(f, "code"), gb(f, "banned"))
    }
}

/** Единый слой: сервер, если он настроен, иначе локальное хранилище. */
object Repo {
    private fun localCodes(st: Store): MutableList<CodeRec> {
        val a = JSONArray(st.rawGet("lcodes"))
        return (0 until a.length()).map { CodeRec.fromJson(a.getJSONObject(it)) }.toMutableList()
    }

    private fun saveLocalCodes(st: Store, l: List<CodeRec>) {
        val a = JSONArray(); l.forEach { a.put(it.toJson()) }; st.rawPut("lcodes", a.toString())
    }

    private fun localUsers(st: Store): MutableList<UserRec> {
        val a = JSONArray(st.rawGet("lusers"))
        return (0 until a.length()).map { UserRec.fromJson(a.getJSONObject(it)) }.toMutableList()
    }

    private fun saveLocalUsers(st: Store, l: List<UserRec>) {
        val a = JSONArray(); l.forEach { a.put(it.toJson()) }; st.rawPut("lusers", a.toString())
    }

    fun getCode(st: Store, code: String): CodeRec? =
        if (Backend.enabled) Backend.getCode(code) else localCodes(st).firstOrNull { it.code == code }

    fun putCode(st: Store, c: CodeRec) {
        if (Backend.enabled) Backend.putCode(c) else {
            val l = localCodes(st).filter { it.code != c.code }.toMutableList(); l.add(c); saveLocalCodes(st, l)
        }
    }

    fun delCode(st: Store, code: String) {
        if (Backend.enabled) Backend.delCode(code) else saveLocalCodes(st, localCodes(st).filter { it.code != code })
    }

    fun codes(st: Store): List<CodeRec> = if (Backend.enabled) Backend.listCodes() else localCodes(st)

    fun getUser(st: Store, id: String): UserRec? =
        if (Backend.enabled) Backend.getUser(id) else localUsers(st).firstOrNull { it.id == id }

    fun putUser(st: Store, u: UserRec) {
        if (Backend.enabled) Backend.putUser(u) else {
            val l = localUsers(st).filter { it.id != u.id }.toMutableList(); l.add(u); saveLocalUsers(st, l)
        }
    }

    fun users(st: Store): List<UserRec> = if (Backend.enabled) Backend.listUsers() else localUsers(st)

    /** Вход по коду: null = успех, иначе текст ошибки. */
    private fun activate(st: Store, code: String): String? {
        val c = getCode(st, code) ?: return "Неверный пароль или код"
        if (!c.active) return "Код отключён"
        if (c.expires != 0L && c.expires < System.currentTimeMillis()) return "Срок действия кода истёк"
        val id = st.deviceId
        if (!c.devices.contains(id)) {
            if (c.devices.size >= c.maxDev) return "Лимит устройств для этого кода исчерпан"
            putCode(st, c.copy(devices = c.devices + id))
        }
        st.codeUsed = code
        return null
    }

    /** Возвращает (роль, ошибка). */
    fun login(st: Store, input: String): Pair<String, String> {
        if (Security.isDev(input)) return "dev" to ""
        if (Security.isUser(input)) { st.codeUsed = ""; return "user" to "" }
        val err = activate(st, input.trim())
        return if (err != null) "" to err else "user" to ""
    }

    /** Повторная проверка при запуске: null = всё ок, иначе причина блокировки. */
    fun validate(st: Store): String? {
        val code = st.codeUsed
        if (code.isNotBlank()) {
            val c = getCode(st, code)
            if (Backend.enabled && c == null) return "Код недоступен или удалён"
            if (c != null) {
                if (!c.active) return "Код отключён"
                if (c.expires != 0L && c.expires < System.currentTimeMillis()) return "Срок действия кода истёк"
            }
        }
        val u = getUser(st, st.deviceId)
        if (u != null && u.banned) return "Вы заблокированы"
        putUser(st, UserRec(st.deviceId, Build.MANUFACTURER + " " + Build.MODEL, System.currentTimeMillis(),
            code, u?.banned ?: false))
        return null
    }
}
