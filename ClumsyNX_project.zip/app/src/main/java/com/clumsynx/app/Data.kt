package com.clumsynx.app

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object Keys {
    val desc = mapOf(
        "loss" to "Часть пакетов пропадает. 10% — заметные рывки, 50% — играть почти нельзя. Для сайтов (TCP) вместо потери добавляется задержка повтора.",
        "delay" to "Каждый пакет ждёт перед отправкой. 100% = 1000 мс (1 секунда).",
        "jitter" to "Случайный разброс задержки до 500 мс — пинг «скачет».",
        "spike" to "Редкие фризы на 0,5–3 секунды. Чем выше значение, тем чаще.",
        "dup" to "Пакеты приходят дважды (только UDP: игры, звонки).",
        "reorder" to "Пакеты приходят не по порядку (только UDP).",
        "corrupt" to "В пакетах портятся байты (только UDP).",
        "throttle" to "Режет скорость: 0% — без лимита, 100% — около 8 кбит/с."
    )
    val list = listOf(
        "loss" to "Потеря пакетов",
        "delay" to "Задержка",
        "jitter" to "Джиттер (разброс задержки)",
        "spike" to "Лаг-спайки (фризы)",
        "dup" to "Дубликаты пакетов",
        "reorder" to "Перестановка пакетов",
        "corrupt" to "Повреждение пакетов",
        "throttle" to "Ограничение скорости"
    )
}

/** Текущие параметры, которые читает сетевой движок. */
object Params {
    @Volatile var v: Map<String, Int> = emptyMap()
    @Volatile var dir: Int = 0 // 0 = оба направления, 1 = входящие, 2 = исходящие
    fun get(k: String): Int = v[k] ?: 0
}

object VpnState {
    val running = mutableStateOf(false)
    val paused = mutableStateOf(false)
}

data class Cfg(val name: String, val v: Map<String, Int>, val dir: Int) {
    fun toJson(): JSONObject = JSONObject().put("n", name).put("d", dir).put("v", JSONObject(v as Map<*, *>))

    fun share(): String =
        "CNX1:" + Base64.encodeToString(toJson().toString().toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE)

    companion object {
        fun fromJson(o: JSONObject): Cfg {
            val vo = o.getJSONObject("v")
            val m = HashMap<String, Int>()
            vo.keys().forEach { m[it] = vo.getInt(it) }
            return Cfg(o.optString("n", "Конфиг"), m, o.optInt("d", 0))
        }

        fun parse(s: String): Cfg? = try {
            val t = s.trim()
            val b = if (t.startsWith("CNX1:")) t.substring(5) else t
            fromJson(JSONObject(String(Base64.decode(b, Base64.URL_SAFE))))
        } catch (e: Exception) {
            null
        }
    }
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cnx", Context.MODE_PRIVATE)

    val deviceId: String
        get() {
            var id = p.getString("dev", null)
            if (id == null) {
                id = UUID.randomUUID().toString().take(12)
                p.edit().putString("dev", id).apply()
            }
            return id
        }

    var role: String
        get() = p.getString("role", "") ?: ""
        set(x) { p.edit().putString("role", x).apply() }

    var codeUsed: String
        get() = p.getString("code", "") ?: ""
        set(x) { p.edit().putString("code", x).apply() }

    var smart: Boolean
        get() = p.getBoolean("smart", false)
        set(x) { p.edit().putBoolean("smart", x).apply() }

    var fabOn: Boolean
        get() = p.getBoolean("fabOn", false)
        set(x) { p.edit().putBoolean("fabOn", x).apply() }

    var fabSize: Int
        get() = p.getInt("fabSize", 56)
        set(x) { p.edit().putInt("fabSize", x).apply() }

    var dir: Int
        get() = p.getInt("dir", 0)
        set(x) { p.edit().putInt("dir", x).apply() }

    fun loadValues(): Map<String, Int> {
        val o = JSONObject(p.getString("vals", "{}") ?: "{}")
        return Keys.list.associate { it.first to o.optInt(it.first, 0) }
    }

    fun saveValues(m: Map<String, Int>, dir: Int) {
        p.edit().putString("vals", JSONObject(m as Map<*, *>).toString()).putInt("dir", dir).apply()
    }

    fun configs(): MutableList<Cfg> {
        val arr = JSONArray(p.getString("cfgs", "[]") ?: "[]")
        val out = mutableListOf<Cfg>()
        for (i in 0 until arr.length()) out.add(Cfg.fromJson(arr.getJSONObject(i)))
        return out
    }

    fun saveConfigs(l: List<Cfg>) {
        val arr = JSONArray()
        l.forEach { arr.put(it.toJson()) }
        p.edit().putString("cfgs", arr.toString()).apply()
    }

    fun rawGet(k: String): String = p.getString(k, "[]") ?: "[]"
    fun rawPut(k: String, v: String) { p.edit().putString(k, v).apply() }
}
